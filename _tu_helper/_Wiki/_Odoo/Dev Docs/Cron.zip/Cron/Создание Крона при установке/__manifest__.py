{
    'data': [
        'data/ir_cron_data.xml',
    ],
}
