## fenced-code-blocks
categories: Docs - Markdown - Базовый синтаксис
aliases: code blocks, triple backticks
Ограждённые блоки кода: тройные обратные кавычки.
```md
```python
print('hello')
```
```

---

## headings
categories: Docs - Markdown - Базовый синтаксис
aliases: h1 h2 h3
Заголовки: #, ##, ### и т.д.
```md
# Заголовок 1
## Заголовок 2
```
