## live-templates
categories: Tools - PyCharm - Productivity
aliases: templates, snippets
Live Templates — автоподстановка кода по шаблонам.
```text
Key: 'def'
Template: 'def $NAME$($PARAMS$):\n    $END$'
```

---

## debugger
categories: Tools - PyCharm - Debug
aliases: breakpoints
Отладчик: точки остановок, инспекция переменных.
```text
Use Shift+F9 to start debugging
```
